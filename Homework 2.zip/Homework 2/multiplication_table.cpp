#include <iostream>
#include <iomanip>
using namespace std;

main(){
   int i,j,n;
   cout<<"Enter Value for n: ";
   cin>>n;
   for(j=0;j<12;j++){
   for(i=0;i<n;i++){
      
         cout<<j+1<<" "<<"*"<<" "<<i+1<<" = "<<((j+1)*(i+1))<<"\t";
      }
      cout<<endl;
   }

   
}