#include <iostream>
using namespace std;

main(){
   int temp, upper, lower, count=0;
cout<<"Input Upper Limit : ";
cin>>upper;
cout<<"Input lower Limit : ";
cin>>lower;
temp = lower;
if(upper>lower){
   for(;temp<upper;temp++){
      if(temp%2==1){
         count+=temp;
         cout<<temp<<"       ";
      }
   }
   cout<<endl;
   cout<<"The sum of all odd numbers between "<<lower<<" and "<<upper<<"is "<<count<<" ";
}else{
   cout<<upper<<" the Upper Limit is smaller than "<<lower<<" the lower limit";
}
}

   


