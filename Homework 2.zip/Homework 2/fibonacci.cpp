#include <iostream>
using namespace std;

main(){
   unsigned long long int num1=1, num2=0, terms, count=0, temp=0;
   cout<<"Input number of terms : ";
   cin>>terms;
   if(terms<0){
      cout<<"Invalid! Negative numbers";
   }else if(terms==0 | terms==1){
      cout<<0;
   }else if(terms>0){
      while(count<terms){
         cout<<temp<<"  ";
         temp = num1 + num2;
         num1=num2;
         num2=temp;
         count++;
   }
   }else{
       cout<<"That is a number i've ever heard of";
}
}
